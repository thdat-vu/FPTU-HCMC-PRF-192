time_t time ( time_t *tptr );// returns the current calendar time and this time is stored in it�s parameter.
double difftime ( time_t  , time_t ); //returns the difference in seconds between two calendar time arguments.
clock_t clock ( void ); //returns the current date time information using the unit clock tick

