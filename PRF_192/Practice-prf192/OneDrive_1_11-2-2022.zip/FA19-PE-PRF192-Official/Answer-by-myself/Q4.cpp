#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


int main() {
  	system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
	int i, j, rows, space;
  
  
  
  
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
	scanf("%d", &rows);
   for (i = rows; i >= 1; --i) {
      for (j = 1; j <= rows-1; ++j) {
      	for (space = 1; space <= rows - i; ++space) {
         printf("  ");
         printf("* ");
      printf("\n");
   }
}}






  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
