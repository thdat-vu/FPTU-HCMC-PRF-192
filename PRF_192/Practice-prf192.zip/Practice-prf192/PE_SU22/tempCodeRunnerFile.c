void inputArray(int* c,int n){
